//Fatemeh Moghiseh    40223076

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main() {
    int numrun;
    typedef struct time {
        int min;
        int sec;
    } time;
    typedef struct runner {
        char FirstName[25];
        char LastName[25];
        char ID[10];
        time *record;
        time runningTime;
    } runner;

    printf("please enter the number of runners: ");
    scanf("%d" , &numrun);

    runner runners[numrun]; 
    for(int i=0 ; i<numrun ; i++) {
       printf("\nplease enter the first name of runner%d: " , i+1);
        scanf("%s", &runners[i].FirstName);

        printf("please enter the last name of runner%d: "  , i+1);
        scanf("%s", &runners[i].LastName);

        printf("please enter the ID of runner%d: "  , i+1);
        scanf("%s", &runners[i].ID);

        printf("Please enter the runner%d's record for this step: " , i+1);
        scanf("%d%d" , &runners[i].runningTime.min , &runners[i].runningTime.sec);

        runners[i].record = (time*)malloc(2*sizeof(int));
        printf("Please enter the best runner%d's record: " , i+1);
        scanf("%d%d" , &runners[i].record->min , &runners[i].record->sec);

    }
 

    int rec[numrun];
    for (int j=0 ; j<numrun ; j++)
        rec[j] = ((runners[j].runningTime.min)*60)+runners[j].runningTime.sec;
    for (int j=0 ; j<numrun ; j++) {    
        for (int i=0 ; (i+1)<numrun ; i++) {
            if(rec[i] < rec[i+1]){
                int a = rec[i];
                rec[i] = rec[i+1];
                rec[i+1] = a;

                runner c = runners[i];
                runners[i] = runners[i+1];
                runners[i+1] = c;
            }     
        }
    }
    int bestrecthis=rec[numrun-1]; 
   


    int bestrec[numrun];
    for (int j=0 ; j<numrun ; j++)
        bestrec[j] = ((runners[j].record->min)*60)+runners[j].record->sec;
    for (int j=0 ; j<numrun ; j++) {
        for(int i=0 ; (i+1)<numrun ; i++){
            if(bestrec[i] < bestrec[i+1]) {
                int b = bestrec[i];  
                bestrec[i] = bestrec[i+1];
                bestrec[i+1] = b;    
            }   
        }   
    }    
    
    int bestrecbest = bestrec[numrun-1];  
    

    int winners[numrun];
    for(int i=0 ; i<numrun ; i++) {
        if(bestrecthis == ((runners[i].runningTime.min)*60)+runners[i].runningTime.sec ) {

            printf("the winner is: %s %s\n" , runners[i].FirstName , runners[i].LastName);


            if(bestrecthis < ((runners[i].record->min)*60)+runners[i].record->sec)
                printf("She/He was able to break her/his record in this race!\n");
            else
                printf("She/He couldn't break her/his record in this race!\n");  


            if(bestrecthis < bestrecbest)
                printf("She/He was able to break the best record!\n");
            else
                printf("She/He couldn't break the best record!\n");


            for(int j=0 ; j<numrun ; j++) {
                winners[j] = i;
            }
        }
    }

    printf("\nFirst Name\tLast Name\tID     \t      this Record \t the Best Record\n");
    for(int i=(numrun-1) ; i>=0 ; i--){
        printf("%-15s %-15s %-13s %d:%-16d %d:%-d\n" , runners[i].FirstName , runners[i].LastName
        , runners[i].ID , runners[i].runningTime.min , runners[i].runningTime.sec , runners[i].record->min
        , runners[i].record->sec );
    }
    

    for(int i=0 ; i<numrun ; i++)
        free(runners[i].record);


    return 0;
}
